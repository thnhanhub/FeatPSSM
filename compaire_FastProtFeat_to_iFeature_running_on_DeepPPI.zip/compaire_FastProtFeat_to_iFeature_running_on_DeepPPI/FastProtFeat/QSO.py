""" @coding: thnhan
This QSO is used by DeepPPI
"""

import numpy as np
import pandas as pd
from DeepPPI_compaire.FastProtFeat.AAC import AACEncoder
from DeepPPI_compaire.FastProtFeat.AA import AA_idx


def to_indices(sequence, dict_AA_1):
    return [dict_AA_1[aa] for aa in sequence]


def tau_di_peptides():
    delta1 = pd.read_csv('FastProtFeat/supp/Grantham.csv',
                         index_col=0, sep='\t').values  # Grantham
    delta2 = pd.read_csv('FastProtFeat/supp/Schneider-Wrede.csv',
                         index_col=0, sep='\t').values  # Schneider-Wrede
    return delta1 * delta1, delta2 * delta2


class QSOEncoder:
    def __init__(self, lg=30):
        self.minLength = lg + 1
        self.dim = (lg + 20 + lg) * 2
        self.shortName = 'QSO'
        self.fullName = 'Quasi Sequence Order'

    @staticmethod
    def to_feature(sequence, lg=30, omega=0.1):
        # Thành phần 1
        F = AACEncoder().to_feature(sequence)

        # Thành phần 2
        delta1, delta2 = tau_di_peptides()  # get the square of distances
        seq = to_indices(sequence, AA_idx)

        # print(seq)
        tau1 = np.zeros(lg)  # dim = 30
        tau2 = np.zeros(lg)  # dim = 30
        L = len(sequence)
        for k in range(lg):
            s1 = sum([delta1[seq[i]][seq[i + k]] for i in range(L - k - 1)])
            s2 = sum([delta2[seq[i]][seq[i + k]] for i in range(L - k - 1)])
            tau1[k - 1] = s1
            tau2[k - 1] = s2

        mau1 = 1.0 + omega * sum(tau1)
        mau2 = 1.0 + omega * sum(tau2)
        features = np.hstack((tau1, F / mau1, tau1 / mau1, tau2, F / mau2, tau2 / mau2))

        return features


if __name__ == "__main__":
    sequence = 'AFQVNTNINAMNAHVQSALTQNALKTSLERLSSGLRINKAADDASGMTVADSLRSQASSLGQAIANTNDGMGIIQVADKAMDEQLKILDTVKVKAT' \
               'QAAQDGQTTESRKAIQSDIVRLIQGLDNIGNTTTYNGQALLSGQFTNKEFQVGAYSNQSIKASIGSTTSDKIGQVRIATGALITASGDISLTFKQV' \
               'DGVNDVTLESVKVSSSAGTGIGVLAEVINKNSNRTGVKAYASVITTSDVAVQSGSLSNLTLNGIHLGNIADIKKNDSDGRLVAAINAVTSETGVEA' \
               'YTDQKGRLNLRSIDGRGIEIKTDSVSNGPSALTMVNGGQDLTKGSTNYGRLSLTRLDAKSINVVSASDSQHLGFTAIGFGESQVAETTVNLRDVTG' \
               'NFNANVKSASGANYNAVIASGNQSLGSGVTTLRGAMVVIDIAESAMKMLDKVRSDLGSVQNQMISTVNNISITQVNVKAAESQIRDVDFAEESANF' \
               'NKNNILAQSGSYAMSQANTVQQNILRLLT'
    v = QSOEncoder().to_feature(sequence)
    print(v)
    print(v.shape)
