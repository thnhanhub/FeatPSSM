import numpy as np
from sys import path

from DeepPPI_compaire.FastProtFeat import DPC, AAC, AmphiphilicPAAC, QSO, CTD

path.append(path[0] + '/..')


def DeepPPIFeatures(proteinSequence: str):
    """
    @author: thnhan
    Mã hoá một chuỗi protein thành vector dựa trên các phương pháp được giới thiệu trong bài báo của
    Xiuquan Du 2017 (DOI: 10.1021/acs.jcim.7b00028)
    =====
    DeepPPI: Boosting Prediction of Protein−Protein Interactions with Deep Neural Networks

    Dimensional
    ----------------------------
    `1164`.
    """
    f1 = AAC.AACEncoder().to_feature(proteinSequence)
    f2 = DPC.DPCEncoder().to_feature(proteinSequence)
    f3 = CTD.CTDEncoder().to_feature(proteinSequence)
    f4 = QSO.QSOEncoder().to_feature(proteinSequence)
    f5 = AmphiphilicPAAC.APAACEncoder().to_feature(proteinSequence)
    feature = np.hstack((f1, f2, f3, f4, f5))

    return feature


def FastProtFeat_extract_for_DeepPPI(lst_prots):
    """
    @author: thnhan
    Mã hoá một chuỗi protein thành vector dựa trên các phương pháp được giới thiệu trong bài báo của
    Xiuquan Du 2017 (DOI: 10.1021/acs.jcim.7b00028)
    =====
    DeepPPI: Boosting Prediction of Protein−Protein Interactions with Deep Neural Networks

    Dimensional
    ----------------------------
    `1164`.
    """
    lst_feats = []
    for prot in lst_prots:
        prot = prot.replace("U", "")
        prot = prot.replace("X", "")
        prot = prot.replace("B", "")
        f_i = DeepPPIFeatures(prot)
        lst_feats.append(f_i)
    return np.array(lst_feats)


def FASTA_to_ID_SEQ(file_name):
    with open(file_name, 'r') as f:
        lines = f.readlines()
        inds = []
        if len(lines) > 0:
            for i, l in enumerate(lines):
                if l.startswith('>'):
                    inds.append(i)
            inds.append(len(lines))
            IDs, SEQs = [], []
            for i in range(len(inds) - 1):
                item = lines[inds[i]:inds[i + 1]]
                IDs.append(item[0].replace(">", "").strip("\n"))
                seq = ''.join(item[1:])
                seq = seq.replace('\n', '')
                SEQs.append(seq)
        else:
            print("====== FILE is EMPTY =======")
    return IDs, SEQs


if __name__ == "__main__":
    sequence = 'AFQVNTNINAMNAHVQSALTQNALKTSLERLSSGLRINKAADDASGMTVADSLRSQASSLGQAIANTNDGMGIIQVADKAMDEQLKILDTVKVKAT' \
               'QAAQDGQTTESRKAIQSDIVRLIQGLDNIGNTTTYNGQALLSGQFTNKEFQVGAYSNQSIKASIGSTTSDKIGQVRIATGALITASGDISLTFKQV' \
               'DGVNDVTLESVKVSSSAGTGIGVLAEVINKNSNRTGVKAYASVITTSDVAVQSGSLSNLTLNGIHLGNIADIKKNDSDGRLVAAINAVTSETGVEA' \
               'YTDQKGRLNLRSIDGRGIEIKTDSVSNGPSALTMVNGGQDLTKGSTNYGRLSLTRLDAKSINVVSASDSQHLGFTAIGFGESQVAETTVNLRDVTG' \
               'NFNANVKSASGANYNAVIASGNQSLGSGVTTLRGAMVVIDIAESAMKMLDKVRSDLGSVQNQMISTVNNISITQVNVKAAESQIRDVDFAEESANF' \
               'NKNNILAQSGSYAMSQANTVQQNILRLLT'

    print(DeepPPIFeatures(sequence).shape)