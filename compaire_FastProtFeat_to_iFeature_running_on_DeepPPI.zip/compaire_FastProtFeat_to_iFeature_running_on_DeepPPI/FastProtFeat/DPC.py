"""
The dipeptide composition is
used to transform the variable length of proteins to fixed length
feature vectors. A dipeptide composition has been used earlier by
Grassmann et al.67 and Reczko and Bohr68 for the development
of fold recognition methods. We adopt the same dipeptide
composition-based approach in developing a deep neural
networks-based method for predicting protein−protein interaction.
The dipeptide composition gives a fixed pattern length of
400. Dipeptide composition encapsulates information about the
fraction of amino acids as well as their local order. The dipeptide
composition is defined as:

@coding: thnhan
"""
from DeepPPI_compaire.FastProtFeat.AA import di_peptides
from collections import Counter


class DPCEncoder:
    def __init__(self):
        self.minLength = 2  # Length conditions
        self.dim = 400
        self.shortName = 'DC'
        self.fullName = 'DiPeptide Composition'

    def to_feature(self, sequence):
        if len(sequence) >= self.minLength:
            L = len(sequence) - 1
            n_di = [sequence[i:i + 2] for i in range(L)]
            n_di = Counter(n_di)
            features = [n_di[di] / L for di in di_peptides]
            return features
        else:
            print("Error length")

    def example(self, sequence=None):
        if sequence is None:
            sequence \
                = 'AFQVNTNINAMNAHVQSALTQNALKTSLERLSSGLRINKAADDASGMTVADSLRSQASSLGQAIANTNDGMGIIQVADKAMDEQLKILDTVKVKA' \
                  'TQAAQDGQTTESRKAIQSDIVRLIQGLDNIGNTTTYNGQALLSGQFTNKEFQVGAYSNQSIKASIGSTTSDKIGQVRIATGALITASGDISLTFK' \
                  'QVDGVNDVTLESVKVSSSAGTGIGVLAEVINKNSNRTGVKAYASVITTSDVAVQSGSLSNLTLNGIHLGNIADIKKNDSDGRLVAAINAVTSETG' \
                  'VEAYTDQKGRLNLRSIDGRGIEIKTDSVSNGPSALTMVNGGQDLTKGSTNYGRLSLTRLDAKSINVVSASDSQHLGFTAIGFGESQVAETTVNLR' \
                  'DVTGNFNANVKSASGANYNAVIASGNQSLGSGVTTLRGAMVVIDIAESAMKMLDKVRSDLGSVQNQMISTVNNISITQVNVKAAESQIRDVDFAE' \
                  'ESANFNKNNILAQSGSYAMSQANTVQQNILRLLT'
        print('Features Dimensional', self.dim)
        print('Features of protein "{}"\n{}'.format(
            sequence,
            self.to_feature(sequence)))


if __name__ == "__main__":
    seq = 'AFQVNTNINAMNAHVQSALTQNALKTSLERLSSGLRINKAADDASGMTVADSLRSQASSLGQAIANTNDGMGIIQVADKAMDEQLKILDTVKVKA' \
          'TQAAQDGQTTESRKAIQSDIVRLIQGLDNIGNTTTYNGQALLSGQFTNKEFQVGAYSNQSIKASIGSTTSDKIGQVRIATGALITASGDISLTFK' \
          'QVDGVNDVTLESVKVSSSAGTGIGVLAEVINKNSNRTGVKAYASVITTSDVAVQSGSLSNLTLNGIHLGNIADIKKNDSDGRLVAAINAVTSETG' \
          'VEAYTDQKGRLNLRSIDGRGIEIKTDSVSNGPSALTMVNGGQDLTKGSTNYGRLSLTRLDAKSINVVSASDSQHLGFTAIGFGESQVAETTVNLR' \
          'DVTGNFNANVKSASGANYNAVIASGNQSLGSGVTTLRGAMVVIDIAESAMKMLDKVRSDLGSVQNQMISTVNNISITQVNVKAAESQIRDVDFAE' \
          'ESANFNKNNILAQSGSYAMSQANTVQQNILRLLT'
    feat = DPCEncoder().to_feature(seq)
    print(len(feat))
