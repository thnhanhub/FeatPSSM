from AA import AA_1


# """ #1 """
# import re
# protein = re.sub("[XBU]", "", protein)
# protein = list(map(lambda a: AA[a], protein))
# freq = np.zeros(20)
# # for a in protein:
# #     freq[a] += 1
# return freq / L

# """ #2 """
# import re
# freq = np.zeros(20)
# n = 0
# for aa in 'ARNDCEQGHILKMFPSTWYV':
#     prot, freq[n] = re.subn(aa, "", prot)
#     n += 1
# return freq / L


def count_AA(sequence, AA=AA_1):
    """ AA là danh sách 20 axit amin """
    count = dict.fromkeys(AA, 0)
    for aa in sequence:
        count[aa] += 1

    return list(count.values())


def count_keys(sequence, v):
    s = [v[aa] for aa in sequence]
    count = [0] * 20
    for aa in s:
        count[int(aa)] += 1

    return count


def count_DP(sequence):
    n_components = dict()
    for item1 in AA_1:
        for item2 in AA_1:
            item = item1 + item2
            n_components[item] = 0

    for i in range(len(sequence) - 1):
        n_components[sequence[i:i + 2]] += 1  # np.append(tk[protein[i:i+2]], [np.int16(i)])

    return n_components


def count_TC(sequence):
    n_components = dict()
    for item1 in ['1', '2', '3', '4', '5', '6', '7']:
        for item2 in ['1', '2', '3', '4', '5', '6', '7']:
            for item3 in ['1', '2', '3', '4', '5', '6', '7']:
                comp = item1 + item2 + item3
                n_components[comp] = 0

    for i in range(len(sequence) - 2):
        n_components[sequence[i:i + 3]] += 1

    return n_components
