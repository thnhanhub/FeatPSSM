"""
These descriptors are developed by Dubchak et al. The amino acids
are divided into three classes according to attribute, and each
amino acid is encoded by one of the indices 1, 2, 3 according to
which class it belongs. The attributes used here include
hydrophobicity, normalized van der Waals volume, polarity
and polarizability, as in the references. Table S1 shows that amino
acid attributes and corresponding division. [Du et al 2017]
Polar (1): RKEDQN
Neutral (2): GASTPHY
Hydrophobicity (3): CLVIMFW
ref: Xiuquan Du 2017 (DOI: 10.1021/acs.jcim.7b00028)
@coding: thnhan
"""
from collections import Counter, defaultdict
from sys import path

import numpy as np
import pandas as pd

table = pd.read_csv('FastProtFeat/supp/supplement_table_CTD.csv', index_col=0)
# print(table)
table = table.values
# print(table)
group = []
for g in table:
    temp = dict()
    for index in range(3):
        for AA in g[index]:
            temp[AA] = index
    group.append(temp)


# print(len(group))


def sum_AA(g, n_AA):
    t = 0
    for aa in g:
        t += n_AA[aa]
    return t


def encode_C(sequence):
    n_AA = Counter(sequence)
    features = np.zeros(3 * len(table))
    L = len(sequence)
    i = 0
    for g in table:
        s1 = sum_AA(g[0], n_AA) / L
        s2 = sum_AA(g[1], n_AA) / L
        features[i] = s1
        features[i + 1] = s2
        features[i + 2] = 1.0 - s1 - s2
        i += 3
    return features


class CDescriptor:
    def __init__(self):
        self.minLength = 1
        self.shortName = 'C'
        self.fullName = 'Composition'

    @staticmethod
    def to_feature(sequence):
        return encode_C(sequence)


def encode_T(sequence):
    L = len(sequence) - 1
    seq = [sequence[i:i + 2] for i in range(L)]
    n_di = Counter(seq)
    features = np.zeros(3 * len(group))
    i = 0
    for g in group:
        t = [0, 0, 0, 0]
        for p, v in n_di.items():
            g1 = g[p[0]]
            g2 = g[p[1]]
            if g1 != g2:
                t[g1 + g2] += v
        features[i:i + 3] = t[1:]
        i += 3
    return features / L


class TDescriptor:
    def __init__(self):
        self.minLength = 2
        self.shortName = 'T'
        self.fullName = 'Transition'

    @staticmethod
    def to_feature(sequence):
        return encode_T(sequence)


# Nhanh (Faster)
def encode_D_faster(sequence):
    L = len(sequence)
    # seq = [sequence[i:i + 2] for i in range(L)]
    # n_di = Counter(seq)
    features = np.zeros(15 * len(group))
    i = 0
    for g in group:
        # print("\n")
        # t = [0, 0, 0, 0]
        seq = [g[aa] for aa in sequence]  # Chuyen thanh dang [1, 2, 3,...]
        n_di = {0: [], 1: [], 2: []}  # Luu tat ca cac vi tri xuat hien cua 1, 2, 3 trong seq

        # print(seq)
        for j, aa in enumerate(seq):
            n_di[aa].append(j + 1)
        # print(n_di)
        for j in range(3):
            temp = n_di[j]
            # print(temp)
            num = len(temp)
            # print(num)
            if num > 0:
                features[i] = temp[0]
                # print(temp[0])
                features[i + 1] = temp[max(int(0.25 * num) - 1, 0)]
                # print(temp[max(int(0.25 * num)-1, 0)])
                features[i + 2] = temp[max(int(0.50 * num) - 1, 0)]
                # print(temp[max(int(0.50 * num)-1, 0)])
                features[i + 3] = temp[max(int(0.75 * num) - 1, 0)]
                # print(temp[max(int(0.75 * num)-1, 0)])
                features[i + 4] = temp[num - 1]
                # print(temp[num-1])
            i += 5
    return features / L * 100


def encode_D(sequence):
    L = len(sequence)
    features = np.zeros(15 * len(group))
    i = 0
    for ii, g in enumerate(group):
        # print("\n")
        seq = [g[aa] for aa in sequence]  # Chuyen thanh dang [1, 2, 3,...]
        # print(seq)
        n_di = defaultdict(list)  # Luu tat ca cac vi tri xuat hien cua 1, 2, 3 trong seq
        for k, aa in enumerate(seq):
            n_di[aa].append(k + 1)
        # print(n_di)
        for j in range(3):
            # print()
            temp = n_di.get(j, [])
            # print(f'group {ii}, vi tri {j}: {temp}')
            num = len(temp)
            # print(num)
            if num > 0:
                features[i] = temp[0]
                # print(temp[0])
                features[i + 1] = temp[max(int(0.25 * num) - 1, 0)]
                # print(temp[max(int(0.25 * num) - 1, 0)])
                features[i + 2] = temp[max(int(0.50 * num) - 1, 0)]
                # print(temp[max(int(0.50 * num) - 1, 0)])
                features[i + 3] = temp[max(int(0.75 * num) - 1, 0)]
                # print(temp[max(int(0.75 * num) - 1, 0)])
                features[i + 4] = temp[num - 1]
                # print(temp[num - 1])
            i += 5
    return features / L * 100


class DDescriptor:
    def __init__(self):
        self.minLength = 1
        self.shortName = 'D'
        self.fullName = 'Distribution'

    @staticmethod
    def to_feature(sequence):
        return encode_D(sequence)


class CTDEncoder:
    def __init__(self):
        self.minLength = 3
        self.shortName = 'CTD'
        self.fullName = 'Composition, Transition, Distribution'

    @staticmethod
    def to_feature(sequence):
        return np.hstack((encode_C(sequence), encode_T(sequence), encode_D(sequence)))


if __name__ == "__main__":
    seq = 'MARYRCCRSQSRSRYYRQRQRSRRRRRRSCQTRRRAMRCCRPRYRPRCRRH'
    v = CTDEncoder().to_feature(seq)
    print(v)
    print(v.shape)
    c = CDescriptor().to_feature(seq)
    print(c.shape)
    d = DDescriptor().to_feature(seq)
    print(d.shape)
    t = TDescriptor().to_feature(seq)
    print(t.shape)
