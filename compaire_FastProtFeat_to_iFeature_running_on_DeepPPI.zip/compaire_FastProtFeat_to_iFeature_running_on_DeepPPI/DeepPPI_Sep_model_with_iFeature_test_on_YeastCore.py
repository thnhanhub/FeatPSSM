# -*- coding: utf-8 -*-
"""
@thnhan:
- 5-fold cv trên YeastCore (11188 mẫu)

@author: sun, Created on Fri Mar 10 13:39:46 2017
"""
from sys import path

import numpy as np
import pandas as pd
from keras.layers import Dense, Input, Dropout
from keras.layers.merge import concatenate
from keras.models import Model
from keras.optimizers import SGD
from sklearn.metrics import roc_curve, auc
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import StandardScaler

import utils.tools as utils
from DeepPPI_compaire.iFeature.iFeature import iFeature_extract_for_DeepPPI


# path.append(path[0] + '/..')
# path.append(path[-1] + '/DeepPPI_feature_extraction_code_tu_FastProtFeat')
#
# pPath = os.path.split(os.path.realpath(__file__))[0]
# path.append(pPath)


def get_sep_model():
    input_1 = Input(shape=(1164,), name='Protein_a')
    protein_input1 = Dense(
        512,
        activation='relu',
        kernel_initializer='glorot_normal',
        name='High_dim_proA_feature_1')(input_1)
    protein_input1 = Dropout(0.2)(protein_input1)
    protein_input1 = Dense(
        256,
        activation='relu',
        kernel_initializer='glorot_normal',
        name='High_dim_proA_feature_2')(protein_input1)
    protein_input1 = Dropout(0.2)(protein_input1)
    protein_input1 = Dense(
        128,
        activation='relu',
        kernel_initializer='glorot_normal',
        name='High_dim_proA_feature_3')(protein_input1)
    protein_input1 = Dropout(0.2)(protein_input1)

    input_2 = Input(shape=(1164,), name='Protein_b')
    protein_input2 = Dense(
        512,
        activation='relu',
        kernel_initializer='glorot_normal',
        name='High_dim_proB_feature_1')(input_2)
    protein_input2 = Dropout(0.2)(protein_input2)
    protein_input2 = Dense(
        256,
        activation='relu',
        kernel_initializer='glorot_normal',
        name='High_dim_proB_feature_2')(protein_input2)
    protein_input2 = Dropout(0.2)(protein_input2)
    protein_input2 = Dense(
        128,
        activation='relu',
        kernel_initializer='glorot_normal',
        name='High_dim_proB_feature_3')(protein_input2)
    protein_input2 = Dropout(0.2)(protein_input2)

    merged_vector = concatenate([protein_input1, protein_input2], axis=1)

    output = Dense(
        128,
        activation='relu',
        kernel_initializer='glorot_normal',
        name='High_dim_feature_1')(merged_vector)
    outputs = Dense(2, activation='softmax', name='output')(output)

    model = Model(inputs=[input_1, input_2], outputs=outputs)

    sgd = SGD(learning_rate=0.01, momentum=0.9, decay=0.001)
    model.compile(
        loss='categorical_crossentropy', optimizer=sgd, metrics=['accuracy'])

    # model.summary()
    return model


def pred_sep_model(model, X1, X2, y_test, fold_j):
    y_score = model.predict([X1, X2])

    # ====== Keep for comparing with methods, thnhan
    method_result['fold' + str(fold_j)] = {"true_y": y_test, "prob_Y": y_score}
    # ======

    y_test_tmp = utils.to_categorical(y_test)
    fpr, tpr, _ = roc_curve(y_test_tmp[:, 0], y_score[:, 0])
    roc_auc = auc(fpr, tpr)
    y_class = utils.categorical_probas_to_classes(y_score)
    y_test_tmp = y_test
    acc, precision, npv, sensitivity, specificity, mcc, f1 = utils.calculate_performace(
        len(y_class), y_class, y_test_tmp)
    print((
            'DeepPPI-sep:acc=%f,precision=%f,npv=%f,sensitivity=%f,specificity=%f,mcc=%f,f1=%f,roc_auc=%f'
            % (acc, precision, npv, sensitivity, specificity, mcc, f1, roc_auc)))


def get_YeastCore_protein(pos_protein_1, neg_protein_1, profeat_feature):
    """ thnhan """
    pos_neg_protein = pd.concat([pos_protein_1, neg_protein_1], axis=0)

    pos_neg_protein.index = np.arange(posNum + negNum)
    labels = np.array([1] * posNum + [0] * negNum)

    protein_a = profeat_feature.loc[pos_neg_protein.proteinA, :]
    protein_b = profeat_feature.loc[pos_neg_protein.proteinB, :]

    protein_a.index = np.arange(posNum + negNum)
    protein_b.index = np.arange(posNum + negNum)

    protein = pd.concat([protein_a, protein_b], axis=1)

    # change data to numpy type
    X = np.array(protein)
    labels = np.array(labels)

    # # shuffle data
    # np.random.seed(1)
    # index = list(range(len(labels)))
    # np.random.shuffle(index)
    # X = X[index]
    # labels = labels[index]

    print(X.shape)
    return X, labels


import time

start_time = time.time()

dsets = [path[0] + '/dataset/YeastCore/uniprotein.txt']
for dset in dsets:
    print("\ndset:", dset)
    data = pd.read_csv(dset, sep='\t')
    print(data)
    IDs = data.id
    SEQs = data.protein
    print("n_prots:", len(SEQs))
    feats = iFeature_extract_for_DeepPPI(SEQs)
    with open(path[0] + "/dataset/YeastCore/feat_uniprotein.txt", "w") as f:
        for ID, feat in zip(IDs, feats):
            f.write(ID + ",")
            f.write(','.join([str(a) for a in feat]))
            f.write("\n")

# # Run time
extracted_time = time.time() - start_time

rootPath = path[0]
pos = pd.read_csv(rootPath + '/dataset/YeastCore/positive.txt', sep='\t')
neg = pd.read_csv(rootPath + '/dataset/YeastCore/negative.txt', sep='\t')
print(pos)
print(neg)

feature_all = pd.read_csv(rootPath + '/dataset/YeastCore/feat_uniprotein.txt', header=None, index_col=0)
# print(feature_all)

posNum = 5594
negNum = 5594
X, label = get_YeastCore_protein(pos, neg, feature_all)
print(label)

sepscores = []
true_y_all = []
prob_y_all = []
method_result = dict()  # thnhan

skf = StratifiedKFold(n_splits=5, random_state=48, shuffle=True)
for i, (tr_inds, te_inds) in enumerate(skf.split(X, label)):
    X_train, X_test = X[tr_inds], X[te_inds]

    scale = StandardScaler().fit(X_train)
    X_train = scale.transform(X_train)
    X_test = scale.transform(X_test)

    X1_train = X_train[:, 0:1164]
    X2_train = X_train[:, 1164:2328]
    # print(sum(sum(X1_train != X2_train)))

    X1_test = X_test[:, 0:1164]
    X2_test = X_test[:, 1164:2328]

    label_train = label[tr_inds]
    label_test = label[te_inds]

    model = get_sep_model()
    y_train = utils.to_categorical(label_train)
    # print(y_train)
    model.fit([X1_train, X2_train], y_train,
              epochs=30,
              batch_size=32,
              verbose=0)

    pred_sep_model(model, X1_test, X2_test, label_test, i)

total_time = time.time() - start_time
deepPPI_time = time.time() - extracted_time - start_time
print('extracted time: {extracted_time} second')
print('deepPPI time: {deepPPI_time} second')
print('total time: {total_time} second')
