#!/usr/bin/env python
#_*_coding:utf-8_*_

import sys, os, re
pPath = os.path.split(os.path.realpath(__file__))[0]
sys.path.append(pPath)
import numpy as np
import pandas as pd
from sys import path
path.append(path[0] + '/..')
table = pd.read_csv(path[-1] + r'/supp/supplement_table_CTD.csv', index_col=0)
table = table.values
USAGE = """
USAGE:
	python CTDTClass.py input.fasta output amino_acids_group_1 amino_acids_group_2 ... amino_acids_group_N

	input.fasta:                 the input protein sequence file in fasta format.	
	output:                      the encoding file.
	amino_acids_group_x          the amino acids groups.

EXAMPLE:
	python CTDTClass.py example/test-protein.txt CTDTClass.tsv RKEDQN GASTPHY CLVIMFW
"""

def CTDTClass(sequence):
	encodings = []
	for groups in table:
		myOrder = []
		for g in range(len(groups) - 1):
			for g1 in range(g+1, len(groups)):
				myOrder.append('%d%d%d%d' % (g + 1, g1 + 1, g1 + 1, g + 1))

		myDict = {}
		for g in range(len(groups)):
			for aa in groups[g]:
				myDict[aa] = g + 1

		myValues = list(set(myDict.values()))
		myKey = {}
		for v in range(len(myValues)):
			for v1 in range(v, len(myValues)):
				myKey['%d%d' % (myValues[v], myValues[v1])] = '%d%d%d%d' % (
				myValues[v], myValues[v1], myValues[v1], myValues[v])
				myKey['%d%d' % (myValues[v1], myValues[v])] = '%d%d%d%d' % (
				myValues[v], myValues[v1], myValues[v1], myValues[v])

		aaPair = [sequence[j:j + 2] for j in range(len(sequence) - 1)]

		myCount = {}
		for pair in aaPair:
			tmp = myKey['%d%d' %(myDict[pair[0]], myDict[pair[1]])]
			if tmp in myCount:
				myCount[tmp] = myCount[tmp] + 1
			else:
				myCount[tmp] = 1

		for key in myOrder:
			if key in myCount:
				encodings.append(myCount[key] / len(aaPair))
			else:
				encodings.append(0)
		# encodings.append(code)
	return encodings

if __name__ == '__main__':
	seq = 'MARYRCCRSQSRSRYYRQRQRSRRRRRRSCQTRRRAMRCCRPRYRPRCRRH'
	print(len(CTDTClass(seq)))