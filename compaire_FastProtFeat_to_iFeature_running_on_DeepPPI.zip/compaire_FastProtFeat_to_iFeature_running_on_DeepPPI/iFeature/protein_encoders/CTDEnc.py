import numpy as np
import pandas as pd
import re, sys, os, platform
import math

pPath = os.path.split(os.path.realpath(__file__))[0]
sys.path.append(pPath)

table = pd.read_csv(pPath + r'/supp/supplement_table_CTD.csv', index_col=0)
table = table.values


# CTDC
def CountCTDC(seq1, seq2):
    sum = 0
    for aa in seq1:
        sum = sum + seq2.count(aa)
    return sum


def CTDC(sequence):
    encodings = []
    for groups in table:
        for group in groups:
            encodings.append(CountCTDC(group, sequence) / len(sequence))
    return encodings


# CTDT
def CTDT(sequence):
    encodings = []
    for groups in table:
        myOrder = []
        for g in range(len(groups) - 1):
            for g1 in range(g + 1, len(groups)):
                myOrder.append('%d%d%d%d' % (g + 1, g1 + 1, g1 + 1, g + 1))

        myDict = {}
        for g in range(len(groups)):
            for aa in groups[g]:
                myDict[aa] = g + 1

        myValues = list(set(myDict.values()))
        myKey = {}
        for v in range(len(myValues)):
            for v1 in range(v, len(myValues)):
                myKey['%d%d' % (myValues[v], myValues[v1])] = '%d%d%d%d' % (
                    myValues[v], myValues[v1], myValues[v1], myValues[v])
                myKey['%d%d' % (myValues[v1], myValues[v])] = '%d%d%d%d' % (
                    myValues[v], myValues[v1], myValues[v1], myValues[v])

        aaPair = [sequence[j:j + 2] for j in range(len(sequence) - 1)]

        myCount = {}
        for pair in aaPair:
            tmp = myKey['%d%d' % (myDict[pair[0]], myDict[pair[1]])]
            if tmp in myCount:
                myCount[tmp] = myCount[tmp] + 1
            else:
                myCount[tmp] = 1

        for key in myOrder:
            if key in myCount:
                encodings.append(myCount[key] / len(aaPair))
            else:
                encodings.append(0)
    return encodings


# CTDD

def CountCTDD(aaSet, sequence):
    number = 0
    for aa in sequence:
        if aa in aaSet:
            number = number + 1
    cutoffNums = [1, math.floor(0.25 * number), math.floor(0.50 * number), math.floor(0.75 * number), number]
    cutoffNums = [i if i >= 1 else 1 for i in cutoffNums]

    code = []
    for cutoff in cutoffNums:
        myCount = 0
        for i in range(len(sequence)):
            if sequence[i] in aaSet:
                myCount += 1
                if myCount == cutoff:
                    code.append((i + 1) / len(sequence) * 100)
                    break
        if myCount == 0:
            code.append(0)
    return code


def CTDD(sequence):
    encodings = []
    for groups in table:
        for group in groups:
            encodings = encodings + CountCTDD(group, sequence)
    return encodings


def CTD(sequence):
    return np.hstack((CTDC(sequence), CTDT(sequence), CTDD(sequence)))


if __name__ == "__main__":
    # fastas = readFasta("examples/test-protein.txt")
    # a = CTD(fastas)
    # with open("test/CTD.txt", "w") as f:
    # 	for i in a:
    # 		f.write(i[0] + "\t")
    # 		for j in i[1:]:
    # 			f.write(str(j))
    # 			f.write(',')
    # 		f.write("\n")
    seq = 'MARYRCCRSQSRSRYYRQRQRSRRRRRRSCQTRRRAMRCCRPRYRPRCRRH'
    print(len(CTD(seq)))
