#!/usr/bin/env python
#_*_coding:utf-8_*_
# OK
import re, sys, os, platform
import math
pPath = os.path.split(os.path.realpath(__file__))[0]
sys.path.append(pPath)
import re
from collections import Counter
# from readFasta import readFasta
# from sys import path
# path.append(path[0] + '/..')

# def AAC(fastas, **kw):
def AAC(sequence):
	# AA = kw['order'] if kw['order'] != None else 'ACDEFGHIKLMNPQRSTVWY'
	AA = 'ARNDCQEGHILKMFPSTWYV'
	# AA = 'ACDEFGHIKLMNPQRSTVWY'
	
	encodings = []
	# for i in fastas:
		# name, sequence = i[0], re.sub('-', '', i[1])
	# for i in sequences:
	# 	sequence = re.sub('-', '', i)
	count = Counter(sequence)
	# print(count)
	for key in count:
		count[key] = count[key]/len(sequence)
	# code = []
	for aa in AA:
		encodings.append(count[aa])
		# encodings.append(code)
	return encodings



if __name__ == "__main__":
	# fastas = readFasta("examples/test-protein.txt")
	# print(fastas)
	# SEQs = []
	# for i in fastas:
	# 	SEQs.append(i[1])
	# for i in SEQs:
	# 	print(AAC(i))
	# print(SEQs)
	# a = AAC(SEQs)
	# print(a)
	# with open("test/AAC.txt", "w") as f:
	# 	for i in a:
	# 		f.write(i[0] + "\t")
	# 		for j in i[1:]:
	# 			f.write(str(j))
	# 			f.write(',')
	# 		f.write("\n")

    seq = 'AFQVNTNINAMNAHVQSALTQNALKTSLERLSSGLRINKAADDASGMTVADSLRSQASSLGQAIANTNDGMGIIQVADKAMDEQLKILDTVKVKA' \
          'TQAAQDGQTTESRKAIQSDIVRLIQGLDNIGNTTTYNGQALLSGQFTNKEFQVGAYSNQSIKASIGSTTSDKIGQVRIATGALITASGDISLTFK' \
          'QVDGVNDVTLESVKVSSSAGTGIGVLAEVINKNSNRTGVKAYASVITTSDVAVQSGSLSNLTLNGIHLGNIADIKKNDSDGRLVAAINAVTSETG' \
          'VEAYTDQKGRLNLRSIDGRGIEIKTDSVSNGPSALTMVNGGQDLTKGSTNYGRLSLTRLDAKSINVVSASDSQHLGFTAIGFGESQVAETTVNLR' \
          'DVTGNFNANVKSASGANYNAVIASGNQSLGSGVTTLRGAMVVIDIAESAMKMLDKVRSDLGSVQNQMISTVNNISITQVNVKAAESQIRDVDFAE' \
          'ESANFNKNNILAQSGSYAMSQANTVQQNILRLLT'
    print(len(AAC(seq)))