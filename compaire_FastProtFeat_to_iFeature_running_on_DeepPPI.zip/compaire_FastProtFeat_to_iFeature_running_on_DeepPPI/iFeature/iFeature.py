import sys
import pandas as pd
import numpy as np

from DeepPPI_compaire.iFeature.protein_encoders import AACEnc, DPCEnc, CTDEnc, QSOEnc, APAACEnc


# pPath = os.path.split(os.path.realpath(__file__))[0]
# sys.path.append(pPath)
#
#
# # from sys import path
# # path.append(path[0] + '/..')


def DeepPPIFeatures(proteinSequence: str):
    """
    @author: thnhan
    Mã hoá một chuỗi protein thành vector dựa trên các phương pháp được giới thiệu trong bài báo của
    Xiuquan Du 2017 (DOI: 10.1021/acs.jcim.7b00028)
    =====
    DeepPPI: Boosting Prediction of Protein−Protein Interactions with Deep Neural Networks

    Dimensional
    ----------------------------
    `1164`.
    """

    f1 = AACEnc.AAC(proteinSequence)
    f2 = DPCEnc.DPC(proteinSequence)
    f3 = CTDEnc.CTD(proteinSequence)
    f4 = QSOEnc.QSOrder(proteinSequence)
    f5 = APAACEnc.APAAC(proteinSequence)
    feature = np.hstack((f1, f2, f3, f4, f5))
    return feature


def iFeature_extract_for_DeepPPI(lst_prots):
    """
    @author: thnhan
    Mã hoá một chuỗi protein thành vector dựa trên các phương pháp được giới thiệu trong bài báo của
    Xiuquan Du 2017 (DOI: 10.1021/acs.jcim.7b00028)
    =====
    DeepPPI: Boosting Prediction of Protein−Protein Interactions with Deep Neural Networks

    Dimensional
    ----------------------------
    `1164`.
    """
    lst_feats = []
    for prot in lst_prots:
        prot = prot.replace("U", "")
        prot = prot.replace("X", "")
        prot = prot.replace("B", "")
        f_i = DeepPPIFeatures(prot)
        lst_feats.append(f_i)
    return np.array(lst_feats)


def FASTA_to_ID_SEQ(file_name):
    with open(file_name, 'r') as f:
        lines = f.readlines()
        inds = []
        if len(lines) > 0:
            for i, l in enumerate(lines):
                if l.startswith('>'):
                    inds.append(i)
            inds.append(len(lines))
            IDs, SEQs = [], []
            for i in range(len(inds) - 1):
                item = lines[inds[i]:inds[i + 1]]
                IDs.append(item[0].replace(">", "").strip("\n"))
                seq = ''.join(item[1:])
                seq = seq.replace('\n', '')
                SEQs.append(seq)
        else:
            print("====== FILE is EMPTY =======")
    return [IDs, SEQs]



